const students=[{
  "id": 1,
  "first_name": "Sarina",
  "last_name": "Mingard",
  "email": "smingard0@joomla.org"
}, {
  "id": 2,
  "first_name": "Gustav",
  "last_name": "Kaliszewski",
  "email": "gkaliszewski1@cnbc.com"
}, {
  "id": 3,
  "first_name": "Evyn",
  "last_name": "Josling",
  "email": "ejosling2@yolasite.com"
}, {
  "id": 4,
  "first_name": "Farand",
  "last_name": "O' Dornan",
  "email": "fodornan3@sogou.com"
}, {
  "id": 5,
  "first_name": "Tabbatha",
  "last_name": "Hanway",
  "email": "thanway4@photobucket.com"
}, {
  "id": 6,
  "first_name": "Benedicta",
  "last_name": "Noury",
  "email": "bnoury5@statcounter.com"
}, {
  "id": 7,
  "first_name": "Dinny",
  "last_name": "Arrighini",
  "email": "darrighini6@de.vu"
}, {
  "id": 8,
  "first_name": "Charlot",
  "last_name": "Reisen",
  "email": "creisen7@google.cn"
}, {
  "id": 9,
  "first_name": "Peder",
  "last_name": "Todaro",
  "email": "ptodaro8@wordpress.org"
}, {
  "id": 10,
  "first_name": "Jasper",
  "last_name": "Treen",
  "email": "jtreen9@oaic.gov.au"
}]


  module.exports=students