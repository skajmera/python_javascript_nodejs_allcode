// // const express = require("express");
// // const app =express();
// // const port=3000;

// // app.get("/",(req,res)=>{
// //     res.send("welcome to my home page");
// // });

// // ////////
// // app.get("/about",(req,res)=>{
// //     ///// res.send("welcome to my about page");
// //     res.status(200).send("welcome to my about page");
// // });
// // //////////

// // app.get("/contact",(req,res)=>{
// //     ///// res.send("welcome to my about page");
// //     res.send("welcome to my contact page");
// // });

// // /////////
// // app.get("/temp",(req,res)=>{
// //     ///// res.send("welcome to my about page");
// //     res.send("welcome to my temp page");
// // });
// server in open 3000
// // app.listen(port,()=>{
// //     console.log(`server in opne ${port}`);
// // });
// // /////////

// /////////////////////////////////////////////////////////////////////////////////





// ///////////////////////////////////////////////////   3 days 
// const express = require("express");
// const app =express();
// const port=3000;

// app.get("/",(req,res)=>{
//     res.write("<h1>welcome to my home page</h1>");
//     res.write("<h1>welcome to my home page</h1>");
//     res.send();
// });

////////
// app.get("/about",(req,res)=>{
//     /// res.send("welcome to my about page");
//     res.status(200).send("welcome to my about page");
// });
//////////

// app.get("/contact",(req,res)=>{
//     ///// res.send("welcome to my about page");
//     res.send("welcome to my contact page");
// });

/////////
// app.get("/temp",(req,res)=>{
    // res.send({
    //     id:1,
    //     name:"subhash"// // res.json([{
    //         //  about
    // });
    /////////

//     res.json([{
//         id:1,
//         name:"subhash"
//     }]);
// });

// app.listen(port,()=>{
//     console.log(`server in open ${port}`);
// });

// /////////

// ////////////////////////////////////////////////////////////////////////////





// ///////////////////////////////////////////   4 days
