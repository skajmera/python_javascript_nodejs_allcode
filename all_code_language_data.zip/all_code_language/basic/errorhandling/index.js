
var express = require('express');
var app = express();
const fs=require('fs')
///////////////////////////////////////
// app.get('/', function(req, res){
//    var err = new Error("Something went wrong");
//    next(err);
// });
// app.use(function(err, req, res, next) {
//    res.status(500);const fs=require('fs')
//    res.send("Oops, something went wrong.")
// });
// app.listen(3000,()=>{
//     console.log("server connected");
// });

////////////////////////////

// app.get('/', function (req, res, next) {
//     fs.readFile('/file-does-not-exist', function (err, data) {
//       if (err) {
//         next(err) // Pass errors to Express.
//       } else {
//         res.send(data)
//       }
//     })
//   })
////////////////////////////////

// app.get('/', function (req, res, next) {
//     fs.readFile('/home/navgurukul/Desktop/basic/streammod/input.txt', function (err, data) {
//       if (err) {
//         next(err) // Pass errors to Express.
//       } else {
//         res.send(data)
//       }
//     })
//   })
///////////////////////////////////////


/////////////////////////////////////



