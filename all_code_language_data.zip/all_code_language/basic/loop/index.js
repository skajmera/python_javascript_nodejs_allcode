// var numbers = [65, 44, 12, 4];
// numbers.forEach(myFunction)

// function myFunction(item, index, arr) {
//   arr[index] = item * 10;
//   console.log(arr[index]);
//   console.log(item);
//   console.log(item,index);
// }console.log(numbers);
////////////////////////////////////////


// var sum = 0;
// var numbers = [65, 44, 12, 4];
// numbers.forEach(myFunction);
// function myFunction(item) {
//   sum += item;}
// console.log(sum);

////////////////////////////////////

// var fruits = ["apple", "orange", "cherry"];
// fruits.forEach(myFunction);

// function myFunction(item, index) {
//   console.log(index + ":" + item );
// }

//////////////////////////////////////

// var numbers = [4, 9, 16, 25];
// var x = numbers.map(Math.sqrt)
// console.log(x);
///////////////////

// var numbers = [65, 44, 12, 4];
// var newarray = numbers.map(myFunction)
// function myFunction(num) {
//   return num * 10;
// }
// console.log(newarray)
////////////////////////////
                               ////////////  wrong 
// var persons = [
//     {firstname : "Malcom", lastname: "Reynolds"},
//     {firstname : "Kaylee", lastname: "Frye"},
//     {firstname : "Jayne", lastname: "Cobb"}
//   ];
  
  
//   function getFullName(item) {
//     var fullname = [item.firstname,item.lastname].join(" ");
//     return fullname;
//   }
  
//   function myFunction() {
//     console.log(persons.map(getFullName));
// }

////////////////////////////////////////////////////

// const array1 = [6,78,5];

// array1.forEach(element => console.log(element));
/////////////////////////////////////

// let ratings = [5, 4, 5];
// let sum = 0;

// let sumFunction = async function (a, b)
// {
//   return a + b
// }

// ratings.forEach(async function(rating) {
//   sum = await sumFunction(sum, rating)
// })

// console.log(sum)