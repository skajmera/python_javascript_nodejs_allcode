exports.home=(req,res)=>{
    res.send('qwertyuiop')
}