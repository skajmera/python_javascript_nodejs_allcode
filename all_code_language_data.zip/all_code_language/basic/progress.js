// const str=["hello i am aijajjjjss","i'm fine"]
// for (i of str){
//     var countt=0;
//     for(j of i){
//         if (j!==' '){
//             countt++
//     }
// }console.log(countt)}


///////////////////////

// const str=["hello i am aijaj","i'm fine"]
// var lis=[]
// for (i of str){
//     var countt=0
//     for (j of i) {
//     if (j=="a"| j=="i"|j=="o"|j=="u"|j=="e" ){
//         countt++
//         }
//         else{
//             continue
//         }
//           }
//     var dictt={vovel:countt}
//     lis.push(dictt)
//         }
//     console.log(lis)


/////////////////////////////////

// const names=["pratik","somesh", "aajMERA"]
// var lis=[]
// var nu=0;
// for (i of names){
//     var l=[]
//     countt=0;
//     for(j of i){
//         countt++
//         l.push(j)
//     }var dic=`{${i}:${countt},${i}:${l}}`
//     lis.push(dic)
//     nu++
// }
// console.log(lis)



////////////////////////////////

// const names=["pratik","somesh", "aajMERA"]
// var lis=[]
// var nu=0;    
// for (i of names){
//     var l=[]
//     countt=0;
//     var d={}
//     for(j of i){
//         countt++
//         l.push(j)
//     }d[i]=l
//     d[i+1]=countt;
//     lis.push(d)
//     nu++
// }
// console.log(lis)



// var a = ["a", "b", "a", "c", "a", "c", "d", "a", "a", "e"]
// var list = []
// a.map((item) => {
//     if (item === "a") {
//         list.push(item)
//     }
// })
// var count = list.length
// console.log(list,count);


//////////////////////////////////



// const names=[{2:"pratik",5:"somesh",7:"aajMERA"}]
// names.forEach(function(g){
//     console.log(g)})

//////////////////////////////////

// const names=["pratik","somesh","aajMERA"]
// names.forEach(function(g,index){
//     console.log(index+':'+g)})
////////////////////////////////////

// const names=["pratik","somesh","aajMERA"]
// names.forEach(loop)
// function loop(g,index){
//     console.log(index+':'+g)}
//////////////////////////////////////////

// output=[ { pratik: [ 'p', 'r', 'a', 't', 'i', 'k' ], pratik1: 6 },
//   { somesh: [ 's', 'o', 'm', 'e', 's', 'h' ], somesh1: 6 },
//   { aajMERA: [ 'a', 'a', 'j', 'M', 'E', 'R', 'A' ], aajMERA1: 7 } ]

