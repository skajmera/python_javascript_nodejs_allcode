// const add =require("./oper")
// console.log(add.add(5,5));
// console.log(add.sub(10,5));

///////////// or  /////////

const {add,sub,mult,name} =require("./oper");
console.log(add(5,5));
console.log(sub(10,5));
console.log(mult(10,5));
console.log(name);


////////////////////////////////////