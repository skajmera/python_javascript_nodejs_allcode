
//////wrapper function
 ///////(function (exports, require, module, __filename, __dirname) {  

///////});

///////////////  iifi  //////////////////

(function(){
    var a="subhash"
    console.log(a);
})
();
////////////////////////////////////

console.log(__dirname);
console.log(__filename);
/////home/navgurukul/Desktop/basic/modwraper
//////home/navgurukul/Desktop/basic/modwraper/modfun.js


///////////////////////////////////

