const path=require("path");
console.log(path.dirname("home/navgurukul/Desktop/path/path.js"));
console.log(path.extname("home/navgurukul/Desktop/path/path.js"));
console.log(path.basename("home/navgurukul/Desktop/path/path.js"));
console.log(path.parse("home/navgurukul/Desktop/path/path.js"))